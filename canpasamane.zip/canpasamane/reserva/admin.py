from django.contrib import admin
from reserva.models import Reserva
# Register your models here.

admin.site.register(Reserva)