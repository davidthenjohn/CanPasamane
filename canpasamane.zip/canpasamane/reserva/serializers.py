# from django.core.serializers import serialize
# from .models import Reserva

#     serialize('json', Reserva.objects.all())