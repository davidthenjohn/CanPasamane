from django.apps import AppConfig


class UsuariConfig(AppConfig):
    name = 'usuari'
